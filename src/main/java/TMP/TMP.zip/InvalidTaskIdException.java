/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TMP;

/**
 *
 * @author rkissvincze
 */
public class InvalidTaskIdException extends Exception {

    public InvalidTaskIdException() {
        super();
    }
    
    public InvalidTaskIdException(String message) {
        super(message);
    }
}
